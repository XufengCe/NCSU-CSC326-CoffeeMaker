/**
 * 
 */
package dailymixes;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Qitao Yang(yqitao)
/**
 * /**
 * This is the test class of GenreSet
 * 
 * @author Qitao Yang
 * @version 04.05.2023
 *
 */
public class GenreSetTest extends student.TestCase {

    private GenreSet test;
    private GenreSet test2;
    private GenreSet test5;
    private GenreSet test9;
    private GenreSet minSet;
    private GenreSet maxSet;

    /**
     * This is the set up for the class
     */
    public void setUp() {
        test = new GenreSet(2, 4, 6);
        test2 = new GenreSet(2, 4, 6);
        test5 = new GenreSet(1, 4, 8);
        test9 = new GenreSet(2, 7, 7);
        minSet = new GenreSet(0, 0, 0);
        maxSet = new GenreSet(100, 100, 100);
    }


    /**
     * This is the test for getter for rock
     */
    public void testGetRock() {
        assertEquals(4, test.getRock());

    }


    /**
     * This is the test for getter for pop
     */
    public void testGetPop() {
        assertEquals(2, test.getPop());
    }


    /**
     * This is the test for getter for country
     */
    public void testGetCountry() {
        assertEquals(6, test.getCountry());
    }


    /**
     * This is the test for isbooleanisWithRane
     */
    public void testIsBooleanisWithRange() {

        assertFalse(test.isWithinRange(null, null));
        assertFalse(test.isWithinRange(minSet, null));
        assertFalse(test.isWithinRange(null, maxSet));
        GenreSet a = new GenreSet(2, 2, 2);
        GenreSet b = new GenreSet(1, 1, 1);
        GenreSet c = new GenreSet(3, 3, 3);
        GenreSet d = new GenreSet(4, 4, 4);
        GenreSet e = new GenreSet(0, 0, 0);
        assertTrue(a.isWithinRange(b, c));
        assertFalse(a.isWithinRange(c, b));
        assertFalse(a.isWithinRange(d, d));
        GenreSet f = new GenreSet(2, 2, 1);
        GenreSet g = new GenreSet(2, 1, 1);
        GenreSet h = new GenreSet(2, 1, 2);
        GenreSet i = new GenreSet(1, 2, 2);
        GenreSet j = new GenreSet(1, 1, 2);
        GenreSet k = new GenreSet(1, 2, 1);
        assertFalse(a.isWithinRange(c, f));
        assertFalse(a.isWithinRange(c, g));
        assertFalse(a.isWithinRange(c, h));
        assertFalse(a.isWithinRange(c, i));
        assertFalse(a.isWithinRange(c, j));
        assertFalse(a.isWithinRange(c, k));

    }


    /**
     * This is the test method for equals
     */
    public void testEquals() {
        String a = "";
        assertTrue(test.equals(test2));
        assertFalse(test.equals(null));
        assertFalse(test.equals(a));
        assertFalse(test.equals(test5));
        assertFalse(test.equals(test9));
        assertTrue(test.equals(test));

        GenreSet thirdOneDiff = new GenreSet(2, 4, 7);
        assertFalse(test.equals(thirdOneDiff));

    }


    /**
     * This is the test method for compareTo
     */
    public void testCompareTo() {
        GenreSet a = new GenreSet(1, 2, 3);
        GenreSet b = new GenreSet(2, 4, 6);
        GenreSet c = new GenreSet(0, 1, 0);
        GenreSet d = new GenreSet(3, 2, 1);
        assertEquals(-1, a.compareTo(b));
        assertEquals(1, a.compareTo(c));
        assertEquals(0, a.compareTo(d));

    }


    /**
     * This is the test method for toString
     */
    public void testToString() {
        String string = "Pop:2 Rock:4 Country:6";
        GenreSet a = new GenreSet(2, 4, 6);
        assertEquals(a.toString(), string);

    }

}
