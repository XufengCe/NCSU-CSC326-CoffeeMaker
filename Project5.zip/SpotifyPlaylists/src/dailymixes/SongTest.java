/**
 * 
 */
package dailymixes;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Qitao Yang(yqitao)
/**
 * /**
 * This is the song test class
 * 
 * @author Qitao Yang
 * @version 04.05.2023
 */
public class SongTest extends student.TestCase {
    private Song test;
    private Song test2;
    private Song test3;
    private Song test4;

    /**
     * This is the set up for the class
     */
    public void setUp() {
        test = new Song("A", 1, 2, 3, "playA");
        test2 = new Song("B", 1, 2, 3, null);
        test3 = new Song("C", 1, 2, 3, "");
        test4 = new Song("A", 1, 2, 3, "playA");
    }


    /**
     * This is the test for playListName
     */
    public void testGetPlayListName() {
        assertEquals("playA", test.getPlaylistName());
    }


    /**
     * This is the test for toString
     */
    public void testToString() {
        assertEquals("A Pop:1 Rock:2 Country:3 Suggested: playA", test
            .toString());
        assertEquals("No-Playlist B Pop:1 Rock:2 Country:3", test2.toString());
        assertEquals("No-Playlist C Pop:1 Rock:2 Country:3", test3.toString());
    }


    /**
     * This is the test for equals method
     */
    public void testEquals() {
        String aString = "";
        assertTrue(test.equals(test));
        assertFalse(test.equals(null));
        assertTrue(test.equals(test4));
        assertFalse(test.equals(aString));

        Song a = new Song("A", 1, 2, 3, "playA");
        Song b = new Song("A", 1, 2, 3, "playA");
        assertTrue(a.equals(b));

        Song c = new Song("B", 1, 2, 3, "playA");
        assertFalse(a.equals(c));

        Song d = new Song("A", 4, 5, 6, "playA");
        assertFalse(a.equals(d));

        Song e = new Song("A", 4, 5, 6, "playB");
        assertFalse(a.equals(e));

        Song f = new Song("A", 1, 2, 3, "playB");
        assertFalse(a.equals(f));

        Song g = new Song("C", 1, 2, 3, "playA");
        assertFalse(a.equals(g));

    }

}
