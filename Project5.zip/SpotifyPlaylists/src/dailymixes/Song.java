/**
 * 
 */
package dailymixes;

/**
 * This is the clas that will create a song
 * 
 * @author Qitao Yang
 * @version 04.05.2023
 */
public class Song {

    private String name;
    private String suggestedPlaylist;
    private GenreSet genreSet;

    /**
     * This is the constructor of the song
     * 
     * @param name
     *            is the name of song
     * @param pop
     *            is the value of pop
     * @param rock
     *            is the value of rock
     * @param country
     *            is the value of country
     * @param suggested
     *            is the playList
     */
    public Song(String name, int pop, int rock, int country, String suggested) {
        this.name = name;
        this.suggestedPlaylist = suggested;
        this.genreSet = new GenreSet(pop, rock, country);
    }


    /**
     * This is the toString method for Song
     * 
     * @return a string
     */
    public String toString() {
        StringBuilder string = new StringBuilder();
        string.append(name);
        string.append(" Pop:" + genreSet.getPop());
        string.append(" Rock:" + genreSet.getRock());
        string.append(" Country:" + genreSet.getCountry());

        if (suggestedPlaylist != null && suggestedPlaylist.length() > 0) {
            string.append(" Suggested: " + suggestedPlaylist);
        }
        else {
            string.insert(0, "No-Playlist ");
        }

        return string.toString();

    }


    /**
     * This is the getter for name
     * 
     * @return a string of name
     */
    public String getName() {
        return name;
    }


    /**
     * This is the getter method for suggestedPlayList
     * 
     * @return a string
     */
    public String getPlaylistName() {
        return suggestedPlaylist;
    }


    /**
     * This is the getter method for genreSet
     * 
     * @return a GenreSet
     */
    public GenreSet getGenreSet() {
        return genreSet;
    }


    /**
     * This is the equals method for song class that
     * compare different song
     * 
     * @param obj
     *            is the other obj
     * @return true or false
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || this.getClass() != obj.getClass()) {
            return false;
        }
        Song compare = (Song)obj;
        return (this.name.equals(compare.name) && this.genreSet.equals(
            compare.genreSet) && this.suggestedPlaylist.equals(
                compare.suggestedPlaylist));

    }

}
