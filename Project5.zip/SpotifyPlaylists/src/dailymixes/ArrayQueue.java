/**
 * 
 */
package dailymixes;

import queue.EmptyQueueException;
import queue.QueueInterface;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Qitao Yang(yqitao)
/**
 * /**
 * This is my data structure for the project using a circular
 * Array queue
 * 
 * @author Qitao Yang
 * @version 04.05.2023
 * @param <T>
 *            data type passed into the queue
 */
public class ArrayQueue<T> implements QueueInterface<T> {
    private T[] queue;
    private int dequeueIndex; // frontIndex
    private int size;
    private int enqueueIndex; // backIndex
    /**
     * This is the constant for default capacity
     */
    public static final int DEFAULT_CAPACITY = 20;

    /**
     * This is the constructor of the ArrayQueue class
     * 
     * @param capacity
     *            is the capacity of the queue
     */
    @SuppressWarnings("unchecked")
    public ArrayQueue(int capacity) {

        queue = (T[])new Object[capacity + 1];
        dequeueIndex = 0;
        enqueueIndex = queue.length - 1;
        size = 0;
    }


    /**
     * This is the second constructor of the ArrayQueue class
     */
    public ArrayQueue() {
        this(DEFAULT_CAPACITY);

    }


    /**
     * This is the clear method that will empty the queue
     */
    @Override
    public void clear() {
        while (!isEmpty()) {
            dequeue();
        }

    }


    /**
     * This is the dequeue method that will remove the front
     * 
     * @return a object that is being removed
     */
    @Override
    public T dequeue() {
        T front = getFront();
        queue[dequeueIndex] = null;
        dequeueIndex = incrementIndex(dequeueIndex);
        size--;

        return front;
    }


    /**
     * This is the enqueue method that will add to the back of the queue
     * 
     * @param object
     *            is the object being added
     */
    @Override
    public void enqueue(T object) {
        ensureCapacity();
        enqueueIndex = incrementIndex(enqueueIndex);
        queue[enqueueIndex] = object;
        size++;

    }


    /**
     * This is method that gets the front of a queue
     * 
     * @return the front of the queue
     */
    @Override
    public T getFront() {
        if (isEmpty()) {
            throw new EmptyQueueException();
        }

        return queue[dequeueIndex];
    }


    /**
     * This is the method that see if the queue is empty
     * 
     * @return true or false;
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }


    /**
     * This is the getter method for size
     * 
     * @return a number represent size
     */
    public int getSize() {
        return size;
    }


    /**
     * This is the getter method for the length of a queue
     * 
     * @return a number represent length
     */
    public int getLengthOfUnderlyingArray() {
        return queue.length;
    }


    /**
     * This is the method that ensure the Capacity of the queue
     */
    private void ensureCapacity() {
        if ((enqueueIndex + 2) % queue.length == dequeueIndex) {
            T[] oldQueue = queue;
            int oldSize = oldQueue.length - 1;
            int newSize = (2 * oldSize) + 1;
            queue = (T[])new Object[newSize];

            int j = dequeueIndex;
            for (int i = 0; i < oldSize; i++) {
                queue[i] = oldQueue[j];
                j = (j + 1) % oldQueue.length;
            }

            dequeueIndex = 0;
            enqueueIndex = oldSize - 1;

        }
    }


    /**
     * This is the helper method that will increment the index
     * 
     * @param index
     *            value being updated
     * @return a number represent the new index
     */
    private int incrementIndex(int index) {
        return ((index + 1) % queue.length);
    }


    /**
     * This is the toArray method of the queue class
     * 
     * @return a array of object
     */
    public Object[] toArray() {
        if (isEmpty()) {
            throw new EmptyQueueException();
        }
        Object[] array = new Object[size];
        int frontIndex = dequeueIndex;
        for (int i = 0; i < size; i++) {
            array[i] = queue[frontIndex];
            frontIndex = incrementIndex(frontIndex);
        }

        return array;
    }


    /**
     * This is the toString method of the queue class
     * 
     * @return a String
     */
    public String toString() {
        String a = "[]";
        if (isEmpty()) {
            return a;
        }
        StringBuilder string = new StringBuilder();
        int frontIndex = dequeueIndex;
        string.append("[");
        for (int i = 0; i < size; i++) {
            string.append(queue[frontIndex].toString());
            frontIndex = incrementIndex(frontIndex);
            if (i < size - 1) {
                string.append(", ");
            }

        }
        string.append("]");
        return string.toString();

    }


    /**
     * This is the equals method for the queue class
     * 
     * @param obj
     *            is the other object
     * @return true or false
     */
    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }
        if (obj == null || this.getClass() != obj.getClass()) {
            return false;
        }

        ArrayQueue compare = (ArrayQueue)obj;
        if (this.size == 0 && compare.size == 0) {
            return true;
        }
        if (this.size != compare.getSize()) {
            return false;
        }

        Object[] thisArray = this.toArray();
        Object[] compareArray = compare.toArray();

        for (int i = 0; i < size; i++) {
            if (!thisArray[i].equals(compareArray[i])) {
                return false;
            }
        }
        return true;
    }

}
