/**
 * 
 */
package dailymixes;

import java.util.Arrays;
import queue.EmptyQueueException;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Qitao Yang(yqitao)
/**
 * This is the test method
 * 
 * @author Qitao Yang
 * @version 04.05.2023
 * @param <T>
 *            data type being passed into the queue
 *
 */
public class ArraryQueueTest<T> extends student.TestCase {

    private ArrayQueue<String> test;
    private ArrayQueue<String> test2;

    /**
     * This is the set up method
     */
    public void setUp()

    {
        test = new ArrayQueue<String>();
        test2 = new ArrayQueue<String>(10);
    }


    /**
     * This is the test for enqueue method
     */
    public void testEnqueue() {
        test2.enqueue("Apple");
        test2.enqueue("Grape");
        test2.enqueue("Orange");

        assertEquals(3, test2.getSize());

        test2.enqueue("4");
        test2.enqueue("5");
        test2.enqueue("6");
        test2.enqueue("7");
        test2.enqueue("8");
        test2.enqueue("9");
        test2.enqueue("10");

        assertEquals(10, test2.getSize());

        test2.enqueue("11");
        assertEquals(21, test2.getLengthOfUnderlyingArray());

        test2 = new ArrayQueue<String>(10);
        for (int i = 0; i < 8; i++) {
            test2.enqueue("A" + i);
        }
        test2.dequeue();
        test2.dequeue();
        test2.dequeue();
        test2.dequeue();
        test2.enqueue("B");
        test2.enqueue("C");
        test2.enqueue("D");
        test2.enqueue("E");
        test2.enqueue("F");
        test2.enqueue("G");
        test2.enqueue("H");
        test2.enqueue("I");
        test2.enqueue("J");
        test2.enqueue("K");

    }


    /**
     * This is the test for dequeue method
     */
    public void testDequeue() {
        test.enqueue("Apple");
        test.enqueue("Grape");
        test.enqueue("Orange");

        assertEquals("Apple", test.dequeue());
        assertEquals("Grape", test.dequeue());
        assertEquals(1, test.getSize());

    }


    /**
     * This is the test for clear method
     */
    public void testClear() {
        test.enqueue("Apple");
        test.enqueue("Grape");
        test.enqueue("Orange");

        test.clear();
        assertEquals(0, test.getSize());
    }


    /**
     * This is the test for getFront metho
     */
    public void testGetFront() {
        Exception exception = null;
        try {
            test.getFront();
        }
        catch (EmptyQueueException e) {
            exception = e;
        }
        assertTrue(exception instanceof EmptyQueueException);
    }


    /**
     * This is the test for GetLengthOfUnderlyingArray method
     */
    public void testGetLengthOfUnderlyingArray() {
        assertEquals(21, test.getLengthOfUnderlyingArray());
        assertEquals(11, test2.getLengthOfUnderlyingArray());
    }


    /**
     * This is the test that for ensurecapacity
     */
    public void testEnsureCapacity() {
        test.enqueue("Apple");
        test.enqueue("Grape");
        test.enqueue("Orange");

        assertEquals(21, test.getLengthOfUnderlyingArray());
    }


    /**
     * This is the test method for toArray
     */
    public void testToArray() {
        test2.enqueue("A");
        test2.enqueue("B");
        test2.enqueue("C");
        test2.enqueue("D");
        test2.enqueue("E");

        Object[] array = new Object[] { "A", "B", "C", "D", "E" };

        assertTrue(Arrays.equals(test2.toArray(), array));

        Exception exception = null;
        try {
            test.toArray();
        }
        catch (EmptyQueueException e) {
            exception = e;
        }
        assertTrue(exception instanceof EmptyQueueException);

    }


    /**
     * This is the test method for toString
     */
    public void testToString() {
        test2.enqueue("A");
        test2.enqueue("B");
        test2.enqueue("C");
        test2.enqueue("D");
        test2.enqueue("E");

        assertEquals("[A, B, C, D, E]", test2.toString());
        assertEquals("[]", test.toString());
    }


    /**
     * This is the test method for equals
     */
    public void testEquals() {
        String a = "";
        test2.enqueue("A");
        test2.enqueue("B");
        test2.enqueue("C");
        test2.enqueue("D");
        test2.enqueue("E");

        test.enqueue("A");
        test.enqueue("B");
        test.enqueue("C");
        test.enqueue("D");
        test.enqueue("E");

        ArrayQueue<String> test3 = new ArrayQueue<String>();

        test3.enqueue("A");
        test3.enqueue("B");
        test3.enqueue("C");

        ArrayQueue<String> test4 = new ArrayQueue<String>();

        test4.enqueue("1");
        test4.enqueue("2");
        test4.enqueue("3");
        test4.enqueue("4");
        test4.enqueue("5");

        assertTrue(test2.equals(test));
        assertTrue(test2.equals(test2));
        assertFalse(test2.equals(null));
        assertFalse(test2.equals(a));
        assertFalse(test.equals(test3));
        assertFalse(test.equals(test4));

        ArrayQueue<String> test5 = new ArrayQueue<String>();
        ArrayQueue<String> test6 = new ArrayQueue<String>();
        assertTrue(test5.equals(test6));

        test5.enqueue("A");
        test6.enqueue("B");
        assertFalse(test5.equals(test6));

        test5.clear();
        assertFalse(test5.equals(test6));

        test5.enqueue("A");
        test6.clear();
        assertFalse(test6.equals(test5));
    }

}
