/**
 * 
 */
package dailymixes;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Qitao Yang(yqitao)
/**
 * /**
 * This is the class of GenreSet that that will have value of pop, rock
 * and country
 * 
 * @author Qitao Yang
 * @version 04.05.2023
 *
 */
public class GenreSet implements Comparable<GenreSet> {
    private int rock;
    private int pop;
    private int country;

    /**
     * This is the constructor of GenreSet
     * 
     * @param pop
     *            this is the value of pop
     * @param rock
     *            this is the value of rock
     * @param country
     *            this is the value country
     */
    public GenreSet(int pop, int rock, int country) {
        this.pop = pop;
        this.rock = rock;
        this.country = country;
    }


    /**
     * This is the getter method for rock
     * 
     * @return a number value of rock
     */
    public int getRock() {
        return rock;
    }


    /**
     * This is the getter method for pop
     * 
     * @return a number value of pop
     */
    public int getPop() {
        return pop;
    }


    /**
     * This is the getter method for country
     * 
     * @return a number value of country
     */
    public int getCountry() {
        return country;
    }


    /**
     * This is the helper method to check if this GenreSet compare to other set
     * 
     * @param other
     *            is the other GenreSet
     * @return true or false
     */
    private boolean isLessThanOrEqualTo(GenreSet other) {
        return this.pop <= other.pop && this.rock <= other.rock
            && this.country <= other.country;

    }


    /**
     * This is the method to determine if the the GenreSet is in
     * range
     * 
     * @param minGenreSet
     *            the min of set
     * @param maxGenreSet
     *            the max of set
     * @return true or false
     */
    public boolean isWithinRange(GenreSet minGenreSet, GenreSet maxGenreSet) {

        if (minGenreSet == null || maxGenreSet == null) {
            return false;
        }
        return this.isLessThanOrEqualTo(maxGenreSet) && minGenreSet
            .isLessThanOrEqualTo(this);
    }


    /**
     * This is the equals method
     * 
     * @param obj
     *            other object
     * @return true or false
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || this.getClass() != obj.getClass()) {
            return false;
        }
        GenreSet compare = (GenreSet)obj;
        return this.pop == compare.pop && this.rock == compare.rock
            && this.country == compare.country;

    }


    /**
     * This is the method that compare different GenreSet
     * 
     * @param other
     *            is the other genreSet
     * @return a value of result
     */
    @Override
    public int compareTo(GenreSet other) {
        int thisSum = this.pop + this.rock + this.country;
        int otherSum = other.pop + other.rock + other.country;
        if (thisSum < otherSum) {
            return -1;
        }
        if (thisSum > otherSum) {
            return 1;
        }
        else {
            return 0;
        }

    }


    /**
     * This is the toString method
     * 
     * @return a string
     */
    public String toString() {
        return "Pop:" + pop + " Rock:" + rock + " Country:" + country;
    }

}
