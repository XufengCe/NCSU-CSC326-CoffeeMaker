package dailymixes;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Haowen Zhang (Hw109)

// -------------------------------------------------------------------------
/**
 * Test Song class.
 * 
 * @author Hw109
 * @version 2023年10月29日
 */

public class SongTest
    extends student.TestCase
{
    // ~ Fields ................................................................
    private Song song;

    // ~ Constructors ..........................................................
    /**
     * Set up.
     */
    public void setUp()
    {
        song = new Song("The Final Countdown", 30, 45, 3, "p1");
    }


    // ~Public Methods ........................................................
    // ----------------------------------------------------------
    /**
     * Test ToString.
     */
    public void testToString()
    {
        assertTrue(
            song.toString().equals(
                "The Final Countdown Pop:30 Rock:45 Country:3 Suggested: p1"));
        song = new Song("Our Song", 24, 14, 50, null);
        assertEquals(
            "No-Playlist Our Song Pop:24 Rock:14 Country:50",
            song.toString());
        song = new Song("Our Song", 24, 14, 50, "");
        assertEquals(
            "No-Playlist Our Song Pop:24 Rock:14 Country:50",
            song.toString());
    }


    // ----------------------------------------------------------
    /**
     * Test GetPlaylistName.
     */
    public void testGetPlaylistName()
    {
        assertEquals("p1", song.getPlaylistName());
    }


    // ----------------------------------------------------------
    /**
     * Test Equals.
     */
    public void testEquals()
    {
        assertFalse(song.equals(null));
        assertFalse(song.equals("song"));
        assertTrue(song.equals(song));
    }


    // ----------------------------------------------------------
    /**
     * Test GetName.
     */
    public void testGetName()
    {
        assertEquals("The Final Countdown", song.getName());
    }


    // ----------------------------------------------------------
    /**
     * Test GenreSet.
     */
    public void testGenreSet()
    {
        GenreSet temp = new GenreSet(30, 45, 3);
        assertEquals(temp, song.getGenreSet());
    }
}
