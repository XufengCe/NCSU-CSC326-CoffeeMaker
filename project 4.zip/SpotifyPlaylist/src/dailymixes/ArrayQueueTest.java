package dailymixes;

import java.util.Arrays;
import queue.EmptyQueueException;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions
// of those who do.
// -- Haowen Zhang (Hw109)

// -------------------------------------------------------------------------
/**
 * Test the ArrayQueue class.
 * 
 * @author Hw109
 * @version 2023年10月29日
 */

public class ArrayQueueTest
    extends student.TestCase
{
    // ~ Fields ..............................................................
    private ArrayQueue<String> queue;
    private ArrayQueue<String> queue1;

    private String t1 = "Test1";
    private String t2 = "Test2";
    private String t3 = "Test3";
    private String t4 = "Test4";
    private String t5 = "Test5";

    // ~ Constructors ........................................................
    /**
     * Set up.
     */
    public void setUp()
    {
        queue = new ArrayQueue<String>(5);
        queue1 = new ArrayQueue<String>();
    }


    // ~Public Methods .......................................................
    /**
     * Test getSize.
     */
    public void testGetSize()
    {
        queue.enqueue(t1);
        assertEquals(1, queue.getSize());
    }


    /**
     * Test getLengthOfUnderlyingArray.
     */
    public void testGetLengthOfUnderlyingArray()
    {
        assertEquals(6, queue.getLengthOfUnderlyingArray());
        queue.enqueue(t1);
        queue.enqueue(t2);
        queue.dequeue();
        queue.enqueue(t3);
        queue.enqueue(t4);
        queue.enqueue(t5);
        queue.enqueue(t1);
        queue.dequeue();
        queue.enqueue(t2);
        queue.enqueue(t2);
        assertEquals(11, queue.getLengthOfUnderlyingArray());
    }


    /**
     * Test clear.
     */
    public void testClear()
    {
        queue.enqueue(t1);
        queue.enqueue(t2);

        assertEquals(2, queue.getSize());

        assertEquals(t1, queue.dequeue());

        queue.enqueue(t3);
        queue.enqueue(t4);
        queue.enqueue(t5);
        queue.enqueue(t1);

        queue.clear();
        assertTrue(queue.isEmpty());

        queue.enqueue(t1);

        assertEquals(t1, queue.dequeue());
    }


    /**
     * Test toArray.
     */
    public void testToArray()
    {
        Exception thrown = null;
        try
        {
            queue.toArray();
        }
        catch (Exception e)
        {
            thrown = e;
        }
        assertTrue(thrown instanceof EmptyQueueException);

        queue.enqueue(t1);
        queue.enqueue(t2);

        queue.dequeue();

        queue.enqueue(t3);
        queue.enqueue(t4);
        queue.enqueue(t5);
        queue.enqueue(t1);

        queue.dequeue();
        queue.enqueue(t2);

        String[] temp = { t3, t4, t5, t1, t2 };
        assertTrue(Arrays.equals(temp, queue.toArray()));

        queue.enqueue(t2);
        String[] temp1 = { t3, t4, t5, t1, t2, t2 };
        assertTrue(Arrays.equals(temp1, queue.toArray()));

    }


    /**
     * Test toString.
     */
    public void testToString()
    {
        queue.enqueue(t1);
        queue.enqueue(t2);
        queue.enqueue(t3);
        String temp = "[Test1, Test2, Test3]";
        assertEquals(temp, queue.toString());
        queue.dequeue();
        queue.dequeue();
        queue.dequeue();

        assertEquals("[]", queue.toString());

        assertEquals("[]", queue1.toString());

        queue1.enqueue(t1);
        assertEquals("[Test1]", queue1.toString());
        queue1.dequeue();
        assertEquals("[]", queue1.toString());
        queue.clear();

        queue = new ArrayQueue<>(5);
        queue.enqueue(t1);
        queue.enqueue(t2);
        queue.enqueue(t3);
        queue.enqueue(t4);
        queue.enqueue(t5);
        queue.dequeue();
        queue.dequeue();
        queue.enqueue("Test6");
        assertEquals("[Test3, Test4, Test5, Test6]", queue.toString());
    }


    /**
     * Test equals.
     */
    @SuppressWarnings("unlikely-arg-type")
    public void testEquals()
    {
        assertTrue(queue.equals(queue1));
        assertFalse(queue.equals(null));

        queue.enqueue(t1);
        queue.enqueue(t2);

        assertEquals(2, queue.getSize());

        queue1.enqueue(t1);
        queue1.enqueue(t2);
        queue1.enqueue(t3);
        assertFalse(queue.equals(queue1));
        queue1.dequeue();
        assertFalse(queue.equals(queue1));

        queue1.clear();
        queue1.enqueue(t1);
        queue1.enqueue(t2);

        assertTrue(Arrays.equals(queue.toArray(), queue1.toArray()));
        assertTrue(queue.equals(queue1));

        assertFalse(queue.equals("123"));

    }


    /**
     * Test dequeue.
     */
    public void testDequeue()
    {
        Exception thrown = null;
        try
        {
            queue.dequeue();
        }
        catch (Exception e)
        {
            thrown = e;
        }
        assertTrue(thrown instanceof EmptyQueueException);

        queue.enqueue(t1);
        queue.enqueue(t2);

        assertEquals(2, queue.getSize());

        assertEquals(t1, queue.dequeue());

        queue.enqueue(t3);
        queue.enqueue(t4);
        queue.enqueue(t5);
        queue.enqueue(t1);

        queue.dequeue();
        queue.enqueue(t2);

        while (!queue.isEmpty())
        {
            queue.dequeue();
        }
        assertEquals(0, queue.getSize());
    }


    /**
     * Test enqueue.
     */
    public void testEnqueue()
    {
        Exception thrown = null;
        try
        {
            queue.enqueue(null);
        }
        catch (Exception e)
        {
            thrown = e;
        }
        assertTrue(thrown instanceof IllegalArgumentException);

        queue.enqueue(t1);
        queue.enqueue(t2);

        assertEquals(2, queue.getSize());
    }


    /**
     * Test getFront.
     */
    public void testGetFront()
    {
        Exception exception = null;
        try
        {
            queue.getFront();
        }
        catch (Exception e)
        {
            exception = e;
        }
        assertTrue(exception instanceof EmptyQueueException);

        queue1.enqueue(t1);
        queue1.enqueue(t2);
        assertEquals(t1, queue1.getFront());
    }


    /**
     * Test isEmpty.
     */
    public void testIsEmpty()
    {
        assertTrue(queue.isEmpty());
        queue.enqueue(t1);
        assertFalse(queue.isEmpty());
    }

}
