package dailymixes;

//Virginia Tech Honor Code Pledge:
//
//As a Hokie, I will conduct myself with honor and integrity at all times.
//I will not lie, cheat, or steal, nor will I accept the actions of those who
//do.
//-- Haowen Zhang (Hw109)
// -------------------------------------------------------------------------
/**
 * Write a one-sentence summary of your class here. Follow it with additional
 * details about its purpose, what abstraction it represents, and how to use it.
 * 
 * @author Hw109
 * @version 2023年11月3日
 */
public class DailyMixDataException
{
    // ~ Fields ................................................................

    // ~ Constructors ..........................................................
    public DailyMixDataException(String string)
    {

    }
    // ~Public Methods ........................................................

}
