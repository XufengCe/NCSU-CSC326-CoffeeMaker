package dailymixes;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Haowen Zhang (Hw109)

// -------------------------------------------------------------------------
/**
 * Represents a set of music genres with their respective counts. Provides
 * functionalities to get individual genre counts, check if a genre set is
 * within a range, and compare genre sets based on the sum of their counts.
 * 
 * @author Hw109
 * @version 2023年10月29日
 */
public class GenreSet
    implements Comparable<GenreSet>
{
    // ~ Fields ................................................................
    private int rock;
    private int pop;
    private int country;

    // ~ Constructors ..........................................................
    // ----------------------------------------------------------
    /**
     * Initializes a new GenreSet with the provided counts.
     * 
     * @param pop
     *            Count for pop genre.
     * @param rock
     *            Count for rock genre.
     * @param country
     *            Count for country genre.
     */
    public GenreSet(int pop, int rock, int country)
    {

        this.pop = pop;
        this.rock = rock;
        this.country = country;
    }


    // ~Public Methods ........................................................
    // ----------------------------------------------------------
    /**
     * Return rock.
     * 
     * @return Count for rock genre.
     */
    public int getRock()
    {
        return rock;
    }


    // ----------------------------------------------------------
    /**
     * Return pop.
     * 
     * @return Count for pop genre.
     */
    public int getPop()
    {
        return pop;
    }


    // ----------------------------------------------------------
    /**
     * Return country.
     * 
     * @return Count for pop genre.
     */
    public int getCountry()
    {
        return country;
    }


    /**
     * To String.
     * 
     * @return String representation of the genre counts.
     */
    public String toString()
    {
        return "Pop:" + pop + " " + "Rock:" + rock + " " + "Country:" + country;
    }


    /**
     * Checks if the current GenreSet is equal to another object.
     * 
     * @param obj
     *            Object to compare with.
     * @return true if both objects are of type GenreSet and have the same
     *             counts, false otherwise.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        if (this.getClass() != obj.getClass())
        {
            return false;
        }
        GenreSet other = (GenreSet)obj;
        return this.getPop() == other.getPop()
            && this.getRock() == other.getRock()
            && this.getCountry() == other.getCountry();
    }


    // ----------------------------------------------------------
    /**
     * Checks if the current GenreSet is within the range of two other
     * GenreSets.
     * 
     * @param minGenreSet
     *            Minimum range GenreSet.
     * @param maxGenreSet
     *            Maximum range GenreSet.
     * @return true if the current GenreSet is within the range, false
     *             otherwise.
     */
    public boolean isWithinRange(GenreSet minGenreSet, GenreSet maxGenreSet)
    {
        return minGenreSet.isLessThanOrEqualTo(this)
            && this.isLessThanOrEqualTo(maxGenreSet);
    }


    /**
     * Checks if the current GenreSet's counts are less than or equal to another
     * GenreSet's counts.
     * 
     * @param other
     *            GenreSet to compare with.
     * @return true if the current GenreSet's counts are less than or equal to
     *             the other's counts, false otherwise.
     */
    private boolean isLessThanOrEqualTo(GenreSet other)
    {
        return this.getPop() <= other.getPop()
            && this.getRock() <= other.getRock()
            && this.getCountry() <= other.getCountry();
    }


    /**
     * Compares the current GenreSet with another based on the sum of their
     * counts.
     * 
     * @param other
     *            GenreSet to compare with.
     * @return Difference between the sums of the counts.
     */
    public int compareTo(GenreSet other)
    {
        int sum1 = rock + pop + country;
        int sum2 = other.pop + other.rock + other.country;
        return sum1 - sum2;
    }
}
