package dailymixes;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Haowen Zhang (Hw109)

// -------------------------------------------------------------------------
/**
 * Test GenreSet class.
 * 
 * @author Hw109
 * @version 2023年10月29日
 */

public class GenreSetTest
    extends student.TestCase
{
    // ~ Fields ................................................................
    private GenreSet genre;
    private GenreSet genre1;
    private GenreSet genre2;

    // ~ Constructors ..........................................................
    /**
     * Set up.
     */
    public void setUp()
    {
        genre = new GenreSet(5, 6, 7);
        genre1 = new GenreSet(10, 11, 12);
        genre2 = new GenreSet(1, 2, 3);
    }


    // ~Public Methods ........................................................
    // ----------------------------------------------------------
    /**
     * Test GetRock.
     */
    public void testGetRock()
    {
        assertEquals(6, genre.getRock());
    }


    // ----------------------------------------------------------
    /**
     * Test GetPop.
     */
    public void testGetPop()
    {
        assertEquals(5, genre.getPop());
    }


    // ----------------------------------------------------------
    /**
     * Test GetCountry.
     */
    public void testGetCountry()
    {
        assertEquals(7, genre.getCountry());
    }


    // ----------------------------------------------------------
    /**
     * Test ToString.
     */
    public void testToString()
    {
        String temp = "Pop:5 Rock:6 Country:7";
        assertEquals(temp, genre.toString());
    }


    // ----------------------------------------------------------
    /**
     * Test Equals.
     */
    public void testEquals()
    {

        GenreSet genre3 = new GenreSet(10, 6, 3);
        GenreSet genre4 = new GenreSet(100, 10, 3);
        GenreSet genre5 = new GenreSet(13, 10, 3);
        GenreSet genre6 = new GenreSet(13, 10, 6);
        assertFalse(genre.equals(null));
        assertTrue(genre.equals(genre));
        assertFalse(genre.equals("genre"));
        assertFalse(genre3.equals(genre));
        assertFalse(genre3.equals(genre4));
        assertFalse(genre.equals(genre2));
        assertFalse(genre4.equals(genre5));
        assertFalse(genre1.equals(genre3));
        assertFalse(genre5.equals(genre6));
    }


    // ----------------------------------------------------------
    /**
     * Test CompareTo.
     */
    public void testCompareTo()
    {
        assertTrue(genre.compareTo(genre1) < 0);
        assertFalse(genre.compareTo(genre1) > 0);
    }


    // ----------------------------------------------------------
    /**
     * Test IsWithinRange.
     */
    public void testIsWithinRange()
    {
        GenreSet genre3 = new GenreSet(10, 2, 3);
        GenreSet genre4 = new GenreSet(100, 10, 3);
        assertTrue(genre.isWithinRange(genre2, genre1));
        assertFalse(genre.isWithinRange(genre1, genre2));
        assertFalse(genre1.isWithinRange(genre, genre2));
        assertFalse(genre2.isWithinRange(genre, genre1));
        assertFalse(genre3.isWithinRange(genre, genre1));
        assertFalse(genre4.isWithinRange(genre, genre1));
    }

}
