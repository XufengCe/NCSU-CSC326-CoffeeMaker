package dailymixes;

import queue.EmptyQueueException;
import queue.QueueInterface;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Haowen Zhang (Hw109)

// -------------------------------------------------------------------------
/**
 * Represents a queue implemented using an array. Provides functionalities to
 * enqueue, dequeue, and inspect elements in the queue.
 * 
 * @author Hw109
 * @version 2023年10月29日
 * @param <T>
 *            The type of elements held in this queue.
 */

@SuppressWarnings("unchecked")
public class ArrayQueue<T>
    implements QueueInterface<T>
{
    /**
     * The default capacity for the underlying array of the queue when no
     * initial capacity is provided.
     */
    // ~ Fields ................................................................

    public static final int DEFAULT_CAPACITY = 20;
    private T[] queue;
    private int dequeueIndex;
    private int size;
    private int enqueueIndex;

    // ~ Constructors ..........................................................
    // ----------------------------------------------------------
    /**
     * Initializes a new ArrayQueue with the specified capacity.
     * 
     * @param capacity
     *            The initial capacity of the queue.
     */
    public ArrayQueue(int capacity)
    {
        queue = (T[])new Object[capacity + 1];
        enqueueIndex = 0;
        dequeueIndex = 0;
        size = 0;
    }


    // ----------------------------------------------------------
    /**
     * Initializes a new ArrayQueue with the default capacity.
     */
    public ArrayQueue()
    {
        queue = (T[])new Object[DEFAULT_CAPACITY + 1];
        enqueueIndex = 0;
        dequeueIndex = 0;
        size = 0;
    }


    // ~Public Methods ........................................................
    // ----------------------------------------------------------
    /**
     * Get size.
     * 
     * @return The current size of the queue.
     */
    public int getSize()
    {
        return size;
    }


    // ----------------------------------------------------------
    /**
     * Get Length Of Underlying Array.
     * 
     * @return The length of the underlying array.
     */
    public int getLengthOfUnderlyingArray()
    {
        return queue.length;
    }


    /**
     * Ensures that the underlying array has sufficient capacity.
     */
    private void ensureCapacity()
    {
        if (isFull())
        {
            T[] temp =
                (T[])new Object[(getLengthOfUnderlyingArray() - 1) * 2 + 1];
            int tempSize = size;
            for (int i = 0; i < tempSize; i++)
            {
                temp[i] = dequeue();
            }
            queue = temp;
            enqueueIndex = tempSize;
            dequeueIndex = 0;
            size = tempSize;
        }
    }


    /**
     * Increments the given index, considering the circular nature of the array.
     * 
     * @param index
     *            The index to increment.
     * @return The incremented index.
     */
    private int incrementIndex(int index)
    {
        return ((index + 1) % queue.length);

    }


    /**
     * Check is full or not.
     * 
     * @return true if the queue is full, false otherwise.
     */
    private boolean isFull()
    {
        return size >= getLengthOfUnderlyingArray() - 1;
    }


    /**
     * Clears the queue, resetting it to its initial state.
     */
    public void clear()
    {
        queue = (T[])new Object[DEFAULT_CAPACITY + 1];
        size = 0;
        enqueueIndex = 0;
        dequeueIndex = 0;
    }


    // ----------------------------------------------------------
    /**
     * To array.
     * 
     * @return An array representation of the queue.
     */
    public Object[] toArray()
    {
        if (size == 0)
        {
            throw new EmptyQueueException();
        }
        Object[] rtn = new Object[size];

        int index = dequeueIndex;
        for (int i = 0; i < size; i++)
        {

            rtn[i] = queue[index];
            index = incrementIndex(index);
        }

        return rtn;
    }


    /**
     * To String.
     * 
     * @return String representation of the queue.
     */
    public String toString()
    {
        if (isEmpty())
        {
            return "[]";
        }
        StringBuilder s = new StringBuilder();
        s.append("[");
        Object[] temp = toArray();
        for (int i = 0; i < size; i++)
        {

            s.append(temp[i].toString());
            if (i != size - 1)
            {
                s.append(", ");
            }
        }
        s.append("]");
        return s.toString();
    }


    /**
     * Checks if the current ArrayQueue is equal to another object.
     * 
     * @param obj
     *            Object to compare with.
     * @return true if both objects are of type ArrayQueue and have the same
     *             elements, false otherwise.
     */
    public boolean equals(Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        if (this.getClass() != obj.getClass())
        {
            return false;
        }
        if (this.size != ((ArrayQueue<T>)obj).size)
        {
            return false;
        }
        if (this.getSize() == 0)
        {
            return true;
        }
        Object[] temp1 = this.toArray();
        Object[] temp2 = ((ArrayQueue<T>)obj).toArray();
        for (int i = 0; i < temp1.length; i++)
        {
            if (!(temp1[i].equals(temp2[i])))
            {
                return false;
            }
        }
        return true;
    }


    /**
     * Removes and returns the front item from the queue.
     *
     * @return The front item from the queue.
     * @throws EmptyQueueException
     *             If the queue is empty.
     */
    @Override
    public T dequeue()
    {

        if (size == 0)
        {
            throw new EmptyQueueException();
        }
        T rtn = queue[dequeueIndex];

        queue[dequeueIndex] = null;
        dequeueIndex = incrementIndex(dequeueIndex);
        size--;
        return rtn;
    }


    /**
     * Adds a new item to the back of the queue.
     *
     * @param obj
     *            The item to be added to the back of the queue.
     * @throws NullPointerException
     *             If the provided item is null.
     */
    @Override
    public void enqueue(T obj)
    {
        if (obj == null)
        {
            throw new IllegalArgumentException();
        }
        ensureCapacity();

        queue[enqueueIndex] = obj;
        enqueueIndex = incrementIndex(enqueueIndex);
        size++;
    }


    /**
     * Retrieves, but does not remove, the front item from the queue.
     *
     * @return The front item from the queue.
     */
    @Override
    public T getFront()
    {
        if (isEmpty())
        {
            throw new EmptyQueueException();
        }
        return queue[dequeueIndex];
    }


    /**
     * Checks if the queue is empty.
     *
     * @return True if the queue is empty, false otherwise.
     */
    @Override
    public boolean isEmpty()
    {
        return size == 0;
    }
}
