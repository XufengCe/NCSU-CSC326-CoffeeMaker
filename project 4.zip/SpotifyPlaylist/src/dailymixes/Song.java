package dailymixes;

// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Haowen Zhang (Hw109)

// -------------------------------------------------------------------------
/**
 * Represents a song with its name, associated genre set, and a suggested
 * playlist. Provides functionalities to retrieve song details and check if two
 * songs are equal.
 * 
 * @author Hw109
 * @version 2023年10月29日
 */

public class Song
{
    // ~ Fields ................................................................
    private String name;
    private String suggestedPlaylist;
    private GenreSet genreSet;

    // ~ Constructors ..........................................................
    // ----------------------------------------------------------
    /**
     * Initializes a new Song with the provided details.
     * 
     * @param name
     *            Name of the song.
     * @param pop
     *            Count for pop genre.
     * @param rock
     *            Count for rock genre.
     * @param country
     *            Count for country genre.
     * @param suggested
     *            Name of the suggested playlist.
     */
    public Song(String name, int pop, int rock, int country, String suggested)
    {
        this.name = name;
        this.suggestedPlaylist = suggested;
        this.genreSet = new GenreSet(pop, rock, country);
    }


    // ~Public Methods ........................................................
    // ----------------------------------------------------------
    /**
     * To String.
     * 
     * @return String representation of the song details.
     */
    public String toString()
    {
        if (this.suggestedPlaylist == null
            || this.suggestedPlaylist.length() <= 0)
        {
            return "No-Playlist " + getName() + " " + getGenreSet().toString();
        }
        return getName() + " " + getGenreSet().toString() + " " + "Suggested: "
            + getPlaylistName();
    }


    // ----------------------------------------------------------
    /**
     * Get Playlist Name.
     * 
     * @return Name of the suggested playlist.
     */
    public String getPlaylistName()
    {
        return this.suggestedPlaylist;
    }


    /**
     * Checks if the current Song is equal to another object.
     * 
     * @param obj
     *            Object to compare with.
     * @return true if both objects are of type Song and have the same details,
     *             false otherwise.
     */
    @Override
    public boolean equals(Object obj)
    {
        if (obj == null)
        {
            return false;
        }
        if (this.getClass() != obj.getClass())
        {
            return false;
        }
        return toString().equals(((Song)obj).toString());
    }


    // ----------------------------------------------------------
    /**
     * Get name.
     * 
     * @return Name of the song.
     */
    public String getName()
    {
        return name;
    }


    // ----------------------------------------------------------
    /**
     * Get Genreset.
     * 
     * @return Associated genre set of the song.
     */
    public GenreSet getGenreSet()
    {
        return this.genreSet;
    }
}
