package dailymixes;

//Virginia Tech Honor Code Pledge:
//
//As a Hokie, I will conduct myself with honor and integrity at all times.
//I will not lie, cheat, or steal, nor will I accept the actions of those who
//do.
//-- Haowen Zhang (Hw109)

// -------------------------------------------------------------------------
/**
 * Write a one-sentence summary of your class here. Follow it with additional
 * details about its purpose, what abstraction it represents, and how to use it.
 * 
 * @author Hw109
 * @version 2023年11月3日
 */
public class PlaylistCalculator
{
    // ~ Fields ................................................................
    private Playlist[] playlists;
    public static final int NUM_PLAYLISTS;
    public static final int MIN_PERCENT;
    private AList<Song> rejectedTracks;
    private ArrayQueue<Song> songQueue;
    public static final int MAX_PERCENT;

    // ~ Constructors ..........................................................
    public PlaylistCalculator(ArrayQueue<Song> queue, Playlist[] list)
    {

    }


    public AList​(int initialCapacity ) {
        
    }


    // ~Public Methods ........................................................
    public void reject()
    {

    }


    private Playlist getPlaylistWithMostRoom(Song song)
    {

    }


    public boolean addSongToPlaylist()
    {

    }


    public Playlist getPlaylistForSong(Song nextSong)
    {

    }


    public ArrayQueue<Song> getQueue()
    {

    }


    private boolean canAccept(Playlist playlist, Song song)
    {

    }


    public int getPlaylistIndex(String playlist)
    {

    }


    public Playlist[] getPlaylists()
    {

    }
}
